# Hovercraft Test Drive Report

## 1. Session Identity
- Session: f0212aa8a806 — 
- Start: 2026-07-24 09:29:35 UTC, duration 66.6 s, mode StandardTestDrive
- Schema 1.3, Unity 6000.5.0f1, fixed dt 0.01 s
- Recorder overhead: 0.025 ms per sampled step; dropped samples: 0

## 2. Craft Configuration
- Hovercraft V2 Apex Hyperclass 11T Prototype (ApexHyperclass), mass 11000 kg, config hash `84ebf1345246ea9d`
- Downward assist 0 m/s², air density 1.225
- Full config: `active_craft_config.json`

## 3. Track and Test Conditions
- Scene: SampleScene; track context: section index / arc length / centerline offset recorded
- Tester notes: 

## 4. Executive Summary
- 66.6 s, 17.56 km, max 1356 km/h (avg 950), grounded 59.4 s / airborne 7.1 s / inverted 7.7 s
- Bottoming: 5 confirmed (+9 near); hard landings 1, spins 0, respawns 0
- Impacts: 3 distinct (3 chassis / 0 wall / 0 high-energy); contact intervals 27 (12 scrapes)
- Steering: 1 numb events (0.40 s) + 1 contact-constrained events (chassis was scraping — not free-running steering weakness)
- Clearance: min free 0.019 m, max penetration -0.352 m, near-bottoming 0.44 s, confirmed-bottoming 10.12 s
- Hover commands (per node, RAW MAY EXCEED THE HARDWARE CEILING): avg raw 1.55 / p95 raw 10.06 / avg clamped 2.21 / avg applied 1.91
- Legacy overdrive metrics (Rev4 semantics — any command above 1; NOT valid for Apex band interpretation, see the operating-band section): continuous-saturated 0.00 s, emergency-saturated 38.20 s, overdrive 48.28 s
- Power: reactor overload 0.00 s; hover power-limited 0.00 s; vectoring power-limited 0.00 s (overload ≠ hover starvation)
- Acceleration by class (Rev1.1 — classified before aggregation, nothing deleted): valid free-driving 24.9 g | grounded non-contact 39.9 g | chassis scrape 89.3 g | collision 0.0 g | landing 116.5 g | respawn/discontinuity 0.8 g | unknown 62.6 g
- Legacy acceleration metric (pre-classification, contact-contaminated — NOT valid continuous driving): 116.5 g

## 5. Driver Notes and Manual Markers
- none

## 6. Key Problems Detected / 19. Suspected Tuning Constraints
1. Bottoming/near-bottoming occurred 14x; emergency hover capacity was reached in 93% of them, power starvation in 0%, excessive downforce flagged in 29%, roof-force opposition in 64%.
2. Numb steering occurred 1x (0.4s total); tilt safety flagged in 0%, thruster saturation in 0%, energy limiting in 0%, yaw damping in 100%.
3. Hover power limitation was not observed.
4. Hover emergency overdrive engaged for 48.28s total (81% of grounded time).

## 7-8. Hover Performance & Bottoming (by speed band)

| Speed Band | Samples | Avg Clearance | Min Clearance | Avg Cmd | Saturated s | Bottoming | Avg Downforce N |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0-200 | 126 | 2.28 | 2.18 | 0.21 | 0.00 | 0 | 1294 |
| 200-400 | 68 | 2.17 | 1.96 | 0.51 | 0.08 | 0 | 17756 |
| 400-600 | 74 | 2.08 | 2.00 | 0.62 | 0.18 | 0 | 48100 |
| 600-800 | 120 | 1.46 | -0.35 | 0.55 | 0.14 | 0 | 100737 |
| 800-1000 | 1508 | 1.53 | -0.35 | 1.82 | 15.06 | 2 | 121208 |
| 1000-1200 | 1075 | 1.42 | -0.35 | 2.34 | 16.84 | 1 | 221212 |
| 1200+ | 358 | 1.20 | -0.35 | 2.59 | 5.90 | 2 | 307460 |

## 9-10. Steering Performance (by speed band)

| Speed Band | Samples | Avg Input | Yaw Accel per Input rad/s² | Avg Slip ° | Numb s | Collisions |
|---|---:|---:|---:|---:|---:|---:|
| 0-200 | 126 | 0.40 | 9.041 | 0.6 | 0.00 | 0 |
| 200-400 | 68 | 0.00 | 0.000 | 0.5 | 0.00 | 0 |
| 400-600 | 74 | 0.00 | 0.000 | 0.0 | 0.00 | 0 |
| 600-800 | 120 | 0.67 | 3.918 | 0.3 | 0.00 | 0 |
| 800-1000 | 1508 | 0.55 | 8.259 | 3.5 | 0.00 | 1 |
| 1000-1200 | 1075 | 0.57 | 8.781 | 2.6 | 0.40 | 1 |
| 1200+ | 358 | 0.30 | 11.606 | 0.8 | 0.00 | 1 |

## Steering Limiter Breakdown

| Limiter | Time Active s |
|---|---:|
| Tilt safety | 0.06 |
| Roll-rate safety | 0.26 |
| Energy scaling | 0.00 |
| Thruster saturation | 38.20 |
| Traction clamp | 0.00 |

## Load Budget & Operating Bands (Continuous/Performance/Extreme/Emergency/Saturated scheme)
- Capacities: continuous 640,000 N / high-load 1,280,000 N / emergency 4,480,000 N
- Band time: Continuous 23.4 s | Performance 11.1 s | Extreme 21.2 s | Emergency 10.6 s | Saturated 0.3 s
- Longest single interval: Continuous 4.43 s | Performance 0.30 s | Extreme 1.12 s | Emergency 0.60 s | Saturated 0.08 s
- Avg / max speed by band: Continuous 783/1344 km/h | Performance 1037/1351 km/h | Extreme 1040/1356 km/h | Emergency 1045/1355 km/h | Saturated 1011/1336 km/h
- Avg clearance by band: Continuous 2.06 m | Performance 1.49 m | Extreme 1.13 m | Emergency 1.45 m | Saturated 0.86 m
- Emergency share of grounded time: 18% (target < 35%); saturated share 0% (target < 15%)
- Per-section budget: section_load_budget.csv; compatibility classes + recommended speeds: section_compatibility.csv (diagnostics, not caps)

## 13-14. Aerodynamic Loads & Power
- Peak downforce 325187 N; avg power 1842 / peak 4406; reactor overloaded 0.00 s (hover-limited 0.00 s, vectoring-limited 0.00 s)

## 15. Collision and Scrape Summary
- Contact intervals 27 (12 scrapes); distinct impact events 3. See collisions.csv.

## 17. Performance by Track Section
- See track_sections.csv (14 sections visited)

## 18. Event Timeline
-    2.80s  EmergencyOverdrive (sev 2, 244 km/h, 0.04s) [EmergencyForceReached]
-    3.28s  EmergencyOverdrive (sev 2, 315 km/h, 0.04s) [EmergencyForceReached]
-    3.36s  EmergencyOverdrive (sev 2, 327 km/h, 0.02s) [EmergencyForceReached]
-    3.36s  ProbeSurfaceChanged (sev 1, 327 km/h, 0.02s)
-    3.42s  ProbeSurfaceChanged (sev 1, 335 km/h, 0.02s)
-    3.52s  EmergencyOverdrive (sev 2, 350 km/h, 0.08s) [EmergencyForceReached]
-    3.58s  UnexpectedLaunch (sev 2, 367 km/h, 0.08s) — aero: v=101.9m/s vVert=4.5m/s gravity=107910N hover=135956N GE=12723N body=13968N surfaces=0N torque=9147Nm AoA=-2.5deg slip=-0.2deg probes=4/4 upVsNormal=2deg fwdVsAirflow=3deg [CurvatureRelease, EmergencyRelease, CrestTransition]
-    3.92s  EmergencyOverdrive (sev 2, 407 km/h, 0.06s) [EmergencyForceReached]
-    3.98s  UnexpectedLaunch (sev 2, 423 km/h, 0.08s) — aero: v=117.6m/s vVert=4.0m/s gravity=107910N hover=194507N GE=16952N body=18625N surfaces=0N torque=12162Nm AoA=-2.0deg slip=0.0deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [EmergencyRelease]
-    4.12s  EmergencyOverdrive (sev 2, 435 km/h, 0.08s) [EmergencyForceReached]
-    4.16s  UnexpectedLaunch (sev 2, 448 km/h, 0.10s) — aero: v=124.6m/s vVert=4.6m/s gravity=107910N hover=175807N GE=19005N body=20883N surfaces=0N torque=13647Nm AoA=-2.1deg slip=0.0deg probes=4/4 upVsNormal=3deg fwdVsAirflow=2deg [CurvatureRelease, EmergencyRelease, CrestTransition]
-    4.28s  EmergencyOverdrive (sev 2, 457 km/h, 0.06s) [EmergencyForceReached]
-    4.34s  UnexpectedLaunch (sev 2, 473 km/h, 0.12s) — aero: v=131.5m/s vVert=4.4m/s gravity=107910N hover=200711N GE=21167N body=23258N surfaces=0N torque=15181Nm AoA=-1.9deg slip=0.0deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [CurvatureRelease, EmergencyRelease]
-    4.52s  UnexpectedLaunch (sev 2, 498 km/h, 0.10s) — aero: v=138.3m/s vVert=4.5m/s gravity=107910N hover=362177N GE=23418N body=25733N surfaces=0N torque=16795Nm AoA=-1.9deg slip=0.0deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [CurvatureRelease, EmergencyRelease, CrestTransition]
-    4.70s  EmergencyOverdrive (sev 2, 514 km/h, 0.04s) [EmergencyForceReached]
-    4.78s  EmergencyOverdrive (sev 2, 525 km/h, 0.04s) [EmergencyForceReached]
-    4.72s  UnexpectedLaunch (sev 2, 525 km/h, 0.16s) — aero: v=145.8m/s vVert=5.1m/s gravity=107910N hover=356772N GE=26024N body=28592N surfaces=0N torque=18674Nm AoA=-2.0deg slip=0.0deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [CurvatureRelease, EmergencyRelease, CrestTransition]
-    4.90s  EmergencyOverdrive (sev 2, 541 km/h, 0.08s) [EmergencyForceReached]
-    4.96s  UnexpectedLaunch (sev 2, 557 km/h, 0.08s) — aero: v=154.6m/s vVert=4.1m/s gravity=107910N hover=111035N GE=29270N body=32203N surfaces=0N torque=20992Nm AoA=-1.5deg slip=-0.1deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [CurvatureRelease, EmergencyRelease, CrestTransition]
-    5.20s  EmergencyOverdrive (sev 2, 581 km/h, 0.02s) [EmergencyForceReached]
-    5.20s  UnexpectedLaunch (sev 2, 588 km/h, 0.20s) — aero: v=163.5m/s vVert=4.2m/s gravity=107910N hover=200989N GE=32734N body=35984N surfaces=0N torque=23445Nm AoA=-1.5deg slip=-0.1deg probes=4/4 upVsNormal=1deg fwdVsAirflow=1deg [CurvatureRelease, EmergencyRelease, CrestTransition]
-    5.46s  EmergencyOverdrive (sev 2, 615 km/h, 0.02s) [EmergencyForceReached]
-    5.46s  UnexpectedLaunch (sev 2, 623 km/h, 3.50s) — aero: v=172.9m/s vVert=6.0m/s gravity=107910N hover=163668N GE=36629N body=40244N surfaces=0N torque=26275Nm AoA=-2.0deg slip=0.0deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [CurvatureRelease, EmergencyRelease, CrestTransition, Unknown]
-    5.62s  EmergencyOverdrive (sev 2, 636 km/h, 0.04s) [EmergencyForceReached]
-    5.76s  EmergencyOverdrive (sev 2, 654 km/h, 0.02s) [EmergencyForceReached]
-    6.76s  EmergencyOverdrive (sev 2, 780 km/h, 0.02s) [EmergencyForceReached]
-    6.86s  ContinuousReserveDepleted (sev 1, 824 km/h, 0.52s) [ContinuousForceReached]
-    7.34s  EmergencyOverdrive (sev 2, 851 km/h, 0.08s) [EmergencyForceReached]
-    7.44s  EmergencyOverdrive (sev 2, 864 km/h, 0.12s) [EmergencyForceReached]
-    7.74s  EmergencyOverdrive (sev 2, 902 km/h, 0.04s) [EmergencyForceReached]
-    7.80s  EmergencyOverdrive (sev 2, 909 km/h, 0.02s) [EmergencyForceReached]
-    7.86s  EmergencyOverdrive (sev 2, 917 km/h, 0.04s) [EmergencyForceReached]
-    7.92s  EmergencyOverdrive (sev 2, 924 km/h, 0.06s) [EmergencyForceReached]
-    8.08s  EmergencyOverdrive (sev 2, 944 km/h, 0.02s) [EmergencyForceReached]
-    8.14s  EmergencyOverdrive (sev 2, 952 km/h, 0.12s) [EmergencyForceReached]
-    8.38s  EmergencyOverdrive (sev 2, 981 km/h, 0.28s) [EmergencyForceReached]
-    8.68s  EmergencyOverdrive (sev 2, 1016 km/h, 0.08s) [EmergencyForceReached]
-    8.78s  EmergencyOverdrive (sev 2, 1028 km/h, 0.02s) [EmergencyForceReached]
-    8.82s  EmergencyOverdrive (sev 2, 1032 km/h, 0.08s) [EmergencyForceReached]
-    8.94s  EmergencyOverdrive (sev 2, 1046 km/h, 0.22s) [EmergencyForceReached]
-    9.02s  UnexpectedLaunch (sev 2, 1061 km/h, 0.14s) — aero: v=294.8m/s vVert=8.7m/s gravity=107910N hover=1379244N GE=106429N body=116949N surfaces=0N torque=76274Nm AoA=-1.7deg slip=0.8deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [EmergencyRelease, CrestTransition]
-    9.18s  EmergencyOverdrive (sev 2, 1072 km/h, 11.44s) [EmergencyForceReached]
-    9.22s  PerformanceHoverInterval (sev 1, 1092 km/h, 0.20s)
-    9.42s  UnexpectedLaunch (sev 2, 1101 km/h, 0.26s) — aero: v=305.7m/s vVert=7.8m/s gravity=107910N hover=1345367N GE=114511N body=125854N surfaces=0N torque=82024Nm AoA=-1.5deg slip=0.8deg probes=4/4 upVsNormal=3deg fwdVsAirflow=2deg [CurvatureRelease, CrestTransition, Unknown]
-    9.48s  ContinuousReserveDepleted (sev 1, 1124 km/h, 0.44s) [ContinuousForceReached]
-    9.74s  UnexpectedLaunch (sev 2, 1127 km/h, 0.12s) — aero: v=313.1m/s vVert=6.7m/s gravity=107910N hover=1358237N GE=120075N body=132021N surfaces=0N torque=85971Nm AoA=-1.2deg slip=0.2deg probes=4/4 upVsNormal=2deg fwdVsAirflow=1deg [Unknown]
-    9.94s  ExtremeHoverInterval (sev 2, 1147 km/h, 0.18s) [ContinuousForceReached]
-    9.94s  ContinuousReserveDepleted (sev 1, 1153 km/h, 1.46s) [ContinuousForceReached]
-    9.18s  ProlongedEmergencyHover (sev 3, 1153 km/h, 11.44s) [EmergencyForceReached]
-   10.20s  MainSaturation (sev 1, 1160 km/h, 8.98s) [EnergyLimiting]
-   10.32s  ExtremeHoverInterval (sev 2, 1161 km/h, 0.34s) [ContinuousForceReached]
-   10.76s  UnexpectedLaunch (sev 2, 1158 km/h, 0.30s) — aero: v=321.6m/s vVert=11.6m/s gravity=107910N hover=2553242N GE=126670N body=139156N surfaces=0N torque=90955Nm AoA=-2.1deg slip=0.1deg probes=4/4 upVsNormal=3deg fwdVsAirflow=2deg [Unknown]
-   10.94s  HighLoadReserveDepleted (sev 2, 1134 km/h, 0.46s) [ContinuousForceReached]
-   11.50s  ContinuousReserveDepleted (sev 1, 1089 km/h, 1.86s) [ContinuousForceReached]
-   11.56s  HighLoadReserveDepleted (sev 2, 1084 km/h, 1.60s) [ContinuousForceReached]
-   11.76s  EmergencyHoverInterval (sev 2, 1074 km/h, 0.46s) [EmergencyForceReached]
-   12.26s  EmergencyHoverInterval (sev 2, 1020 km/h, 0.30s) [EmergencyForceReached]
-   12.76s  EmergencyHoverInterval (sev 2, 975 km/h, 0.60s) [EmergencyForceReached]
-   13.38s  ContinuousReserveDepleted (sev 1, 922 km/h, 0.72s) [ContinuousForceReached]
-   13.40s  HighLoadReserveDepleted (sev 2, 921 km/h, 0.30s) [ContinuousForceReached]
- … 272 more, see events.csv

## 20. Data Quality and Missing Signals
- Dropped samples: 0; recorder overhead 0.025 ms/sampled step.

## 21. Exported Files
session_metadata.json, core_frames.csv, hover_nodes.csv, thrusters.csv, extended_systems.csv, aero_frames.csv, aero_surfaces.csv, events.csv, collisions.csv, track_sections.csv, driver_markers.csv, session_compact.json, *.hoverdrive.json, active_craft_config.json, recorder_log.txt.
- A ZIP bundle is also attempted next to the session folder; ZIP failures are reported in the Unity Console.
