# Hovercraft Test Drive Report

## 1. Session Identity
- Session: b8b805dcdb25 — 
- Start: 2026-07-24 11:43:34 UTC, duration 49.8 s, mode StandardTestDrive
- Schema 1.3, Unity 6000.5.0f1, fixed dt 0.01 s
- Recorder overhead: 0.019 ms per sampled step; dropped samples: 0

## 2. Craft Configuration
- Hovercraft V3 Apex Hyperclass — Phase-Vector Rings (ApexHyperclass), mass 11000 kg, config hash `3fbeb3efc5a7cffa`
- Downward assist 0 m/s², air density 1.225
- Full config: `active_craft_config.json`

## 3. Track and Test Conditions
- Scene: SampleScene; track context: section index / arc length / centerline offset recorded
- Tester notes: 

## 4. Executive Summary
- 49.8 s, 11.41 km, max 1275 km/h (avg 825), grounded 27.6 s / airborne 22.2 s / inverted 4.3 s
- Bottoming: 2 confirmed (+4 near); hard landings 0, spins 0, respawns 0
- Impacts: 2 distinct (2 chassis / 0 wall / 0 high-energy); contact intervals 39 (5 scrapes)
- Steering: 0 numb events (0.00 s) + 0 contact-constrained events (chassis was scraping — not free-running steering weakness)
- Clearance: min free 0.007 m, max penetration -0.354 m, near-bottoming 0.78 s, confirmed-bottoming 6.06 s
- Hover commands (per node, RAW MAY EXCEED THE HARDWARE CEILING): avg raw 0.00 / p95 raw 0.00 / avg clamped 0.00 / avg applied 0.00
- Legacy overdrive metrics (Rev4 semantics — any command above 1; NOT valid for Apex band interpretation, see the operating-band section): continuous-saturated 0.00 s, emergency-saturated 0.00 s, overdrive 0.00 s
- Power: reactor overload 0.00 s; hover power-limited 0.00 s; vectoring power-limited 0.00 s (overload ≠ hover starvation)
- Acceleration by class (Rev1.1 — classified before aggregation, nothing deleted): valid free-driving 39.6 g | grounded non-contact 39.9 g | chassis scrape 49.2 g | collision 0.0 g | landing 39.9 g | respawn/discontinuity 1.5 g | unknown 90.6 g
- Legacy acceleration metric (pre-classification, contact-contaminated — NOT valid continuous driving): 90.6 g

## 5. Driver Notes and Manual Markers
- none

## 6. Key Problems Detected / 19. Suspected Tuning Constraints
1. Bottoming/near-bottoming occurred 6x; emergency hover capacity was reached in 0% of them, power starvation in 0%, excessive downforce flagged in 100%, roof-force opposition in 0%.
2. Hover power limitation was not observed.

## 7-8. Hover Performance & Bottoming (by speed band)

| Speed Band | Samples | Avg Clearance | Min Clearance | Avg Cmd | Saturated s | Bottoming | Avg Downforce N |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0-200 | 117 | 2.45 | 2.37 | 0.00 | 0.00 | 0 | 1411 |
| 200-400 | 67 | 2.40 | 2.37 | 0.00 | 0.00 | 0 | 17660 |
| 400-600 | 74 | 2.40 | 2.35 | 0.00 | 0.00 | 0 | 48150 |
| 600-800 | 777 | 2.12 | -0.35 | 0.00 | 0.00 | 0 | 11899 |
| 800-1000 | 947 | 1.19 | -0.35 | 0.00 | 0.00 | 1 | 80647 |
| 1000-1200 | 388 | 0.99 | -0.35 | 0.00 | 0.00 | 0 | 234008 |
| 1200+ | 121 | 1.42 | -0.35 | 0.00 | 0.00 | 1 | 291831 |

## 9-10. Steering Performance (by speed band)

| Speed Band | Samples | Avg Input | Yaw Accel per Input rad/s² | Avg Slip ° | Numb s | Collisions |
|---|---:|---:|---:|---:|---:|---:|
| 0-200 | 117 | 0.00 | 0.000 | 1.4 | 0.00 | 0 |
| 200-400 | 67 | 0.00 | 0.000 | 0.4 | 0.00 | 0 |
| 400-600 | 74 | 0.00 | 0.000 | 0.3 | 0.00 | 0 |
| 600-800 | 777 | 0.58 | 12.265 | 16.8 | 0.00 | 0 |
| 800-1000 | 947 | 0.51 | 13.771 | 12.2 | 0.00 | 1 |
| 1000-1200 | 388 | 0.34 | 8.298 | 7.2 | 0.00 | 0 |
| 1200+ | 121 | 0.43 | 10.142 | 13.9 | 0.00 | 1 |

## Steering Limiter Breakdown

| Limiter | Time Active s |
|---|---:|
| Tilt safety | 0.00 |
| Roll-rate safety | 0.00 |
| Energy scaling | 0.00 |
| Thruster saturation | 0.00 |
| Traction clamp | 0.00 |

## Load Budget & Operating Bands (Continuous/Performance/Extreme/Emergency/Saturated scheme)
- Capacities: continuous 640,000 N / high-load 1,280,000 N / emergency 4,480,000 N
- Band time: Continuous 49.8 s | Performance 0.0 s | Extreme 0.0 s | Emergency 0.0 s | Saturated 0.0 s
- Longest single interval: Continuous 49.82 s | Performance 0.00 s | Extreme 0.00 s | Emergency 0.00 s | Saturated 0.00 s
- Avg / max speed by band: Continuous 825/1275 km/h | Performance 0/0 km/h | Extreme 0/0 km/h | Emergency 0/0 km/h | Saturated 0/0 km/h
- Avg clearance by band: Continuous 1.44 m | Performance n/a | Extreme n/a | Emergency n/a | Saturated n/a
- Emergency share of grounded time: 0% (target < 35%); saturated share 0% (target < 15%)
- Per-section budget: section_load_budget.csv; compatibility classes + recommended speeds: section_compatibility.csv (diagnostics, not caps)

## 13-14. Aerodynamic Loads & Power
- Peak downforce 307371 N; avg power 350 / peak 1078; reactor overloaded 0.00 s (hover-limited 0.00 s, vectoring-limited 0.00 s)

## 15. Collision and Scrape Summary
- Contact intervals 39 (5 scrapes); distinct impact events 2. See collisions.csv.

## 17. Performance by Track Section
- See track_sections.csv (6 sections visited)

## 18. Event Timeline
-    3.25s  ProbeSurfaceChanged (sev 1, 336 km/h, 0.02s)
-    3.59s  UnexpectedLaunch (sev 2, 395 km/h, 0.10s) — aero: v=109.6m/s vVert=4.3m/s gravity=107910N hover=0N GE=14714N body=16160N surfaces=0N torque=10568Nm AoA=-2.2deg slip=0.2deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [Unknown]
-    4.03s  UnexpectedLaunch (sev 2, 457 km/h, 0.14s) — aero: v=126.9m/s vVert=4.2m/s gravity=107910N hover=0N GE=19735N body=21686N surfaces=0N torque=14154Nm AoA=-1.9deg slip=-0.1deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [Unknown]
-    4.21s  UnexpectedLaunch (sev 2, 482 km/h, 0.18s) — aero: v=133.8m/s vVert=4.6m/s gravity=107910N hover=0N GE=21940N body=24106N surfaces=0N torque=15737Nm AoA=-2.0deg slip=-0.3deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [Unknown]
-    4.41s  UnexpectedLaunch (sev 2, 509 km/h, 2.36s) — aero: v=141.4m/s vVert=4.7m/s gravity=107910N hover=0N GE=24490N body=26909N surfaces=0N torque=17561Nm AoA=-1.9deg slip=-0.3deg probes=4/4 upVsNormal=2deg fwdVsAirflow=2deg [Unknown]
-    6.77s  Takeoff (sev 1, 811 km/h) — at 811 km/h | aero: v=225.2m/s vVert=14.6m/s gravity=107910N hover=0N GE=0N body=68064N surfaces=0N torque=44960Nm AoA=-3.7deg slip=-0.5deg probes=4/4 upVsNormal=-1deg fwdVsAirflow=4deg
-    7.55s  Landing (sev 1, 912 km/h) — impact -27.5 m/s | aero: v=253.4m/s vVert=25.7m/s gravity=107910N hover=0N GE=47189N body=85656N surfaces=0N torque=57891Nm AoA=-5.8deg slip=0.5deg probes=4/4 upVsNormal=7deg fwdVsAirflow=6deg
-    7.55s  UnexpectedLaunch (sev 2, 894 km/h, 2.42s) — aero: v=248.5m/s vVert=20.7m/s gravity=107910N hover=0N GE=75618N body=82611N surfaces=0N torque=55124Nm AoA=-4.8deg slip=0.7deg probes=4/4 upVsNormal=5deg fwdVsAirflow=5deg [Unknown]
-   10.27s  UnexpectedLaunch (sev 2, 1156 km/h, 0.44s) — aero: v=321.1m/s vVert=10.5m/s gravity=107910N hover=0N GE=126304N body=138741N surfaces=0N torque=90582Nm AoA=-1.9deg slip=1.1deg probes=4/4 upVsNormal=3deg fwdVsAirflow=2deg [Unknown]
-   10.83s  NearBottoming (sev 2, 1200 km/h, 0.04s) [ExcessiveDownforce]
-   10.87s  ConfirmedBottoming (sev 3, 1203 km/h, 4.26s) [ExcessiveDownforce]
-   10.89s  ChassisImpact (sev 2, 1205 km/h) — TrackCollider_03_02, normal 8.9 m/s, region bottom
-   11.47s  Scrape (sev 1, 1181 km/h) — TrackCollider_03_02, 0.46s, region bottom
-   12.85s  Scrape (sev 1, 1081 km/h) — TrackCollider_03_02, 0.48s, region bottom
-   13.47s  UnexpectedLaunch (sev 2, 904 km/h, 3.04s) — aero: v=251.2m/s vVert=10.6m/s gravity=107910N hover=0N GE=77276N body=84863N surfaces=0N torque=55563Nm AoA=-2.4deg slip=1.4deg probes=4/4 upVsNormal=1deg fwdVsAirflow=3deg [CollisionRebound, Unknown]
-   14.15s  Scrape (sev 1, 843 km/h) — TrackCollider_03_02, 0.37s, region bottom
-   15.01s  Scrape (sev 1, 800 km/h) — TrackCollider_03_02, 0.73s, region bottom
-   15.13s  NearBottoming (sev 2, 820 km/h, 0.24s) [ExcessiveDownforce]
-   15.47s  NearBottoming (sev 2, 862 km/h, 0.44s) [ExcessiveDownforce]
-   15.91s  ConfirmedBottoming (sev 3, 902 km/h, 1.80s) [ExcessiveDownforce]
-   16.33s  ChassisImpact (sev 2, 941 km/h) — TrackCollider_03_02, normal 7.0 m/s, region bottom
-   16.63s  UnexpectedLaunch (sev 2, 945 km/h, 4.72s) — aero: v=262.4m/s vVert=15.3m/s gravity=107910N hover=0N GE=84296N body=92431N surfaces=0N torque=60885Nm AoA=-3.3deg slip=-0.9deg probes=4/4 upVsNormal=3deg fwdVsAirflow=3deg [CollisionRebound, Unknown]
-   17.61s  Scrape (sev 1, 859 km/h) — TrackCollider_03_02, 0.86s, region bottom
-   17.71s  NearBottoming (sev 2, 863 km/h, 0.06s) [ExcessiveDownforce]
-   17.73s  HighSlipAngle (sev 2, 850 km/h, 0.22s) [TractionOpposition]
-   18.33s  HighSlipAngle (sev 2, 851 km/h, 0.28s) [TractionOpposition]
-   18.29s  AeroBroadsidePenalty (sev 2, 839 km/h, 0.36s) [TractionOpposition]
-   19.71s  ProbeSurfaceChanged (sev 1, 944 km/h, 0.04s)
-   21.61s  UnexpectedLaunch (sev 2, 1165 km/h, 0.86s) — aero: v=323.6m/s vVert=4.6m/s gravity=107910N hover=0N GE=128265N body=141017N surfaces=0N torque=91732Nm AoA=-0.8deg slip=-1.1deg probes=4/4 upVsNormal=1deg fwdVsAirflow=1deg [Unknown]
-   22.59s  UnexpectedLaunch (sev 2, 1262 km/h, 0.26s) — aero: v=350.6m/s vVert=13.7m/s gravity=107910N hover=0N GE=150579N body=165252N surfaces=0N torque=108096Nm AoA=-2.2deg slip=-1.6deg probes=4/4 upVsNormal=3deg fwdVsAirflow=3deg [Unknown]
-   22.87s  UnexpectedLaunch (sev 2, 1275 km/h, 0.08s) — aero: v=354.1m/s vVert=4.6m/s gravity=107910N hover=0N GE=153582N body=162879N surfaces=0N torque=113705Nm AoA=-0.8deg slip=-15.0deg probes=4/4 upVsNormal=2deg fwdVsAirflow=15deg [Unknown]
-   23.09s  UnexpectedLaunch (sev 2, 1269 km/h, 0.76s) — aero: v=352.4m/s vVert=11.7m/s gravity=107910N hover=0N GE=152132N body=161199N surfaces=0N torque=114031Nm AoA=-2.0deg slip=-15.6deg probes=4/4 upVsNormal=3deg fwdVsAirflow=16deg [Unknown]
-   23.55s  HighSlipAngle (sev 2, 1242 km/h, 2.32s) [TractionOpposition]
-   23.49s  AeroBroadsidePenalty (sev 2, 1232 km/h, 2.48s) [TractionOpposition]
-   23.99s  UnexpectedLaunch (sev 2, 1216 km/h, 2.94s) — aero: v=337.8m/s vVert=9.4m/s gravity=107910N hover=0N GE=139783N body=168464N surfaces=0N torque=160093Nm AoA=-1.8deg slip=-27.2deg probes=4/4 upVsNormal=3deg fwdVsAirflow=27deg [Unknown]
-   26.99s  UnexpectedLaunch (sev 2, 837 km/h, 0.50s) — aero: v=232.5m/s vVert=6.6m/s gravity=107910N hover=0N GE=66210N body=72727N surfaces=0N torque=47439Nm AoA=-1.6deg slip=-1.5deg probes=4/4 upVsNormal=4deg fwdVsAirflow=2deg [Unknown]
-   27.49s  Takeoff (sev 1, 823 km/h) — at 823 km/h | aero: v=228.5m/s vVert=32.2m/s gravity=107910N hover=0N GE=0N body=69009N surfaces=0N torque=48285Nm AoA=-8.1deg slip=1.3deg probes=4/4 upVsNormal=-1deg fwdVsAirflow=8deg
-   27.57s  ProbeGraceEntered (sev 1, 819 km/h) — Hover_FR: probe missed, holding stale surface (dist 6.73 m)
-   27.57s  ProbeGraceEntered (sev 1, 819 km/h) — Hover_RL: probe missed, holding stale surface (dist 6.81 m)
-   27.57s  ProbeGraceEntered (sev 1, 819 km/h) — Hover_RR: probe missed, holding stale surface (dist 7.07 m)
-   27.59s  ProbeGraceEntered (sev 1, 818 km/h) — Hover_FL: probe missed, holding stale surface (dist 6.81 m)
-   27.61s  ProbeGraceExpired (sev 2, 817 km/h) — Hover_FR: grace window expired — surface lost for real
-   27.61s  ProbeGraceExpired (sev 2, 817 km/h) — Hover_RL: grace window expired — surface lost for real
-   27.61s  ProbeGraceExpired (sev 2, 817 km/h) — Hover_RR: grace window expired — surface lost for real
-   27.63s  ProbeGraceExpired (sev 2, 817 km/h) — Hover_FL: grace window expired — surface lost for real
-   33.39s  ProbeNormalDiscontinuity (sev 2, 796 km/h, 0.02s) [TrackNormalDiscontinuity]
-   33.49s  Landing (sev 1, 805 km/h) — impact -7.6 m/s | aero: v=223.5m/s vVert=15.6m/s gravity=107910N hover=0N GE=36608N body=66254N surfaces=0N torque=43963Nm AoA=-4.0deg slip=6.3deg probes=4/4 upVsNormal=14deg fwdVsAirflow=7deg
-   33.49s  UnexpectedLaunch (sev 2, 809 km/h, 0.90s) — aero: v=224.7m/s vVert=36.8m/s gravity=107910N hover=0N GE=61749N body=65586N surfaces=0N torque=47186Nm AoA=-9.5deg slip=6.6deg probes=4/4 upVsNormal=13deg fwdVsAirflow=11deg [Unknown]
-   34.27s  ProbeGraceEntered (sev 1, 884 km/h) — Hover_FL: probe missed, holding stale surface (dist 1.60 m)
-   34.27s  ProbeGraceEntered (sev 1, 884 km/h) — Hover_FR: probe missed, holding stale surface (dist 1.97 m)
-   34.29s  ProbeGraceEntered (sev 1, 885 km/h) — Hover_RL: probe missed, holding stale surface (dist 2.36 m)
-   34.29s  ProbeGraceEntered (sev 1, 885 km/h) — Hover_RR: probe missed, holding stale surface (dist 2.70 m)
-   34.31s  ProbeGraceExpired (sev 2, 886 km/h) — Hover_FL: grace window expired — surface lost for real
-   34.31s  ProbeGraceExpired (sev 2, 886 km/h) — Hover_FR: grace window expired — surface lost for real
-   34.33s  ProbeGraceExpired (sev 2, 886 km/h) — Hover_RL: grace window expired — surface lost for real
-   34.33s  ProbeGraceExpired (sev 2, 886 km/h) — Hover_RR: grace window expired — surface lost for real
-   34.39s  Takeoff (sev 1, 888 km/h) — at 888 km/h | aero: v=246.7m/s vVert=39.0m/s gravity=107910N hover=0N GE=0N body=77393N surfaces=0N torque=60358Nm AoA=-9.5deg slip=-17.0deg probes=0/4 upVsNormal=-1deg fwdVsAirflow=19deg
-   34.45s  AeroBroadsidePenalty (sev 2, 930 km/h, 2.80s) [TractionOpposition]
-   37.87s  AeroBroadsidePenalty (sev 2, 842 km/h, 1.28s) [TractionOpposition]
-   40.77s  InvertedAirborne (sev 2, 803 km/h, 0.36s)
- … 11 more, see events.csv

## 20. Data Quality and Missing Signals
- Dropped samples: 0; recorder overhead 0.019 ms/sampled step.

## 21. Exported Files
session_metadata.json, core_frames.csv, hover_nodes.csv, thrusters.csv, extended_systems.csv, aero_frames.csv, aero_surfaces.csv, events.csv, collisions.csv, track_sections.csv, driver_markers.csv, session_compact.json, *.hoverdrive.json, active_craft_config.json, recorder_log.txt.
- A ZIP bundle is also attempted next to the session folder; ZIP failures are reported in the Unity Console.
